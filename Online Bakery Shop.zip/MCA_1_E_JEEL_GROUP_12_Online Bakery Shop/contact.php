<?php include "header.php"; ?>	
<head>
	<style type="text/css">
	iframe
	{
		height: 500px;
		width: 2000px;
	}
	</style>
</head>
	<!-- Start All Pages -->
		
		<img src="images/cn.png" width="100%">
	<!-- End All Pages -->
	
	<!-- Start Contact -->
	<div>
		<!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d918.0841636956277!2d72.47745182625192!3d23.01140812252083!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e9bb90242761b%3A0x1ee56cca53e72dac!2sMaher%20Kathiyawadi%20Restaurant!5e0!3m2!1sen!2sin!4v1606132935575!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe> -->
 
 <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7345.413577830291!2d72.49482087857123!3d22.99780719996343!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e9bb26c8446fb%3A0xbb90255dca823505!2sFresh%20N%20Fresh%20Makarba!5e0!3m2!1sen!2sin!4v1663309228924!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> -->
	</div>
	<div class="contact-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>Contact</h2>
						<p>Contact Information are Listed here Thanks for Visit Our Site</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<form id="contactForm">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<h1 style="font-family: cambria; color: red; text-align: center;">Fresh N Fresh Bakery Shop</h1>
									<div class="help-block with-errors"></div>
								</div>                                 
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<center><span style="color: tomato; font-size: 1.3em; text-align: center; "><b>Email Us :</b> freshbakeryshop@gmail.com</span></center>
									<div class="help-block with-errors"></div>
								</div> 
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<center><span style="color: tomato; font-size: 1.3em; text-align: center; "><b>Mobile  :</b> +91 992 5049 234</span></center>
									<div class="help-block with-errors"></div>
								</div> 
							</div>
							<div class="col-md-12">
								<div class="form-group"> 
									<center><span style="color: tomato; font-size: 1.3em; text-align: center; "><b>Location  :</b> GF14 Sammet platinum, Makarba Rd, opp. Makarba crossing, near Prahladnagar, Ahmedabad, Gujarat 380051</span></center>
									<div class="help-block with-errors"></div>
								</div>
								
							</div>
						</div>            
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- End Contact -->
<?php include "footer.php"; ?>