<!-- Start Gallery -->
<div class="gallery-box">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="heading-title text-center">
                    <h2>Gallery</h2>
                    <p>Deliciousness jumping into the mouth</p>
                </div>
            </div>
        </div>
        <div class="tz-gallery">
            <div class="row">
                
                <?php
                        include "connect.php";
                        $s = mysqli_query($con,"select * from gallery");
                        while($r = mysqli_fetch_array($s))
                        {
                ?>
                    <div class="col-sm-12 col-md-4 col-lg-4">
                    
                        <a class="lightbox" href="<?php echo "admin/".$r['image']; ?>">
                            <img class="img-fluid"  src="<?php echo "admin/".$r['image']; ?>" alt="Gallery Images" style="width: 350px; height: 250px;"
                            >

                            
                        </a>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<!-- End Gallery -->
