<?php include "header.php"; ?>	
	<!-- Start All Pages -->
	<div class="all-page-title page-breadcrumb">
		<div class="container text-center">
			<div class="row">
				<div class="col-lg-12">
					<h1>Gallery</h1>
				</div>
			</div>
		</div>
	</div>
	<!-- End All Pages -->
<!-- Stsrt Gallery	 -->
<?php
include("image.php");
?>
<!-- End Gallery -->
<?php include "footer.php"; ?>