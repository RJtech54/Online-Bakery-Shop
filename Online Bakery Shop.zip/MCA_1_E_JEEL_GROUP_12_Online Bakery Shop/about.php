<?php include "header.php"; ?>
	<!-- Start header -->
	<img src="images/banner_about_us2.png" width="100%" >
	<!-- End header -->
	
	<!-- Start About -->
	<div class="about-section-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 text-center">
					<div class="inner-column">
						<h1>Welcome To <span>Fresh N Fresh Bakery Shop</span></h1>
						<h4>Little Story</h4>
<pre><p>
There are several reasons why someone might prefer to
shop for baked goods online rather than at a physical 
bakery. Some of these reasons might include:

<b>Convenience:</b>Online bakeries allow customers to place
orders and make paymentsfrom the comfort of 
their own homes, without having to visit a physical
storefront. This can be especially useful for people
who live in ruralareas or have busy schedules.
</p>
<p>
<b>Wide selection:</b> Online bakeries often have
a wider selection of products than physical stores,
as they have more space to showcase their offerings.
This can be particularly useful for customers who 
are looking for specific types of baked goods or 
who have dietary restrictions.
<!-- </p>

Customization: Many online bakeries allow customers to customize their orders, such as by adding special ingredients or requesting specific shapes or sizes. This can be helpful for people who have specific preferences or needs.

Time-saving: Shopping online can be faster than visiting a physical store, especially if the bakery is located far from the customer's home or if it is a busy time of day.

Easy price comparison: Online bakeries often list prices for their products on their websites, which can make it easier for customers to compare prices and find the best deals.
						</p> -->
 </p>
						
						<!--<a class="btn btn-lg btn-circle btn-outline-new-white" href="#"> Comment</a> -->
					</div>
				</div>
				<div class="col-lg-6 col-md-6">
					<img src="images/images.png" style="height: 450px; width: 100%" class="img-fluid">
				</div>
				<div class="col-md-12">
					<div class="inner-pt">
					<p> To interact with users, online bakery websites typically have a user-friendly interface that allows customers to browse and select products, customize their orders, and make payments. Many online bakeries also have customer service pages or contact forms where users can ask questions or get help with their orders. Some online bakeries may also have social media accounts or newsletters where they can communicate with their customers and share updates about new products or special offers.</p>
	
					<p> Making way for a hearty meal is Fresh N Fresh Bakery Shop in Ahmedabad. This place is synonymous with delicious food that can satiate all food cravings. It is home to some of the most appreciated cuisines. So as to be able to cater to a large number of diners, it occupies a favourable location at Makarba. Opposite Skoda Workshop,SG Highway Road,Makarba-380058 is where one can visit the venue. Courtesy to this strategic location, foodies in and around the neighborhood can walk in to this eating house conveniently without facing any hassles related to commuting to this part of the city. It is one of the most sought after Restaurants in South Bopal. This is a one of the renowned Bakery in Ahmedabad.

 </p>
						<p>Fresh N Fresh Bakery Shop at Makarba makes sure one has a great food experience by offering highly palatable food. The restaurant welcomes guests from 11:00-19:00 - 15:00-00:00 allowing diners to relish a scrumptious meal between the functional hours.The price range of the food at the bakery ranges from 1. This listing is also listed in Bakery, Inexpensive fresh bakery (Below Rs 500), ahmedabad Delivery Bakerys.
 </p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End About -->
<!-- Start Manu -->
<?php
	include("smanu.php");
?>
<!-- End Menu -->

<?php include "footer.php" ; ?>		